let form = document.querySelector("form");
let data = form.getElementsByClassName("form-field");


function control() {
  for (let i = 0; i < data.length; i++) {
    if (data[i] === email) {
      email_control(data[i]);
    } else {
      change(data[i]);
    }
  }
}


function email_control(el) {
  let text = /([a-zA-Z0-9_\.\-])+\@([a-zA-Z0-9]+\.)([a-zA-Z0-9])+/g;
  el.value === "" || !el.value.match(text) ? no_email(el) : there_is_email(el);
}


function no_email(el) {
  el.classList.add("empty-field");
  email.placeholder = "email@example.com";
  el.classList.add("example");
  let id = el.id + "Text";
  let replacement = document.getElementById(id);
  replacement.style.display = "block";
}


function there_is_email(el) {
  el.classList.remove("empty-field");
  el.classList.remove("example");
  var id = el.id + "Text";
  var replacement = document.getElementById(id);
  replacement.style.display = "none";
}


function change(el) {
  el.value === "" ? no_text(el) : there_is_text(el);
}


function no_text(el) {
  el.classList.add("empty-field");
  el.placeholder = "";
  let id = el.id + "Text";
  let replacement = document.getElementById(id);
  replacement.style.display = "block";
}


function there_is_text(el) {
  el.classList.remove("empty-field");
  var id = el.id + "Text";
  var replacement = document.getElementById(id);
  replacement.style.display = "none";
}


form.addEventListener("submit", function (event) {
  event.preventDefault();
  control();
});
